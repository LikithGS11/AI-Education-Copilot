# Module File Tree

```
├── PythonBasics/
│   └── final_project.md
│   └── rubric.md
│   └── summary.md
├── PythonBasics/Day1/
│   └── exercises.md
│   └── lesson.md
│   └── micro_learning.md
│   └── slides.md
│   └── video_script.md
├── PythonBasics/Day2/
│   └── exercises.md
│   └── lesson.md
│   └── micro_learning.md
│   └── slides.md
│   └── video_script.md
```