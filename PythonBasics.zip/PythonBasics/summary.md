# Python Basics
## 2-Day Module Overview
### Module Overview
* Title: Python Basics
* Duration: 2 days
* Level: Beginner
* Prerequisites: None
* Learning Objectives:
  * Recall basic Python syntax and data types
  * Explain how to write and execute Python scripts
  * Apply basic control structures (if/else statements, loops)
  * Analyze and evaluate the use of functions in Python
  * Create a simple Python program using a GUI library
