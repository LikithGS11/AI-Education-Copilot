# Final Project
## Description
Create a simple Python program using a GUI library to calculate the area of a rectangle
## Requirements
* Use a GUI library to create a window
* Add buttons and labels to the window
* Create a function to calculate the area of the rectangle
* Use the function to calculate the area of the rectangle when the user clicks a button
## Timeline
* Due date: 1 week from the last day of the module
## Resources
* GUI library documentation
* Python documentation
## Submission Guidelines
* Submit your project as a zip file
* Include a brief write-up of your project
