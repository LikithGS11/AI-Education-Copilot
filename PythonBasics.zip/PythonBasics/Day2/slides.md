# Day 2 Slides
## Title Slide
Python Basics
## Learning Objectives
* Apply basic control structures (if/else statements, loops)
* Analyze and evaluate the use of functions in Python
* Create a simple Python program using a GUI library
## Content Slide 1
### Control Structures
* If/else statements
* Loops
## Content Slide 2
### Functions
* Defining functions
* Calling functions
## Content Slide 3
### GUI Programming
* Introduction to GUI programming
* Using a GUI library
## Content Slide 4
### Creating a Simple GUI Program
* Creating a window
* Adding buttons and labels
## Summary Slide
Recap of key concepts
## Next Steps
Start with practice exercises