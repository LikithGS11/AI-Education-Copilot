# Day 2 Micro-Learning Chunks
## Duration: 10 minutes each
## Focus
Single concept or skill
## Format
Video, reading, exercise, or combination
## Assessment
Quick check for understanding