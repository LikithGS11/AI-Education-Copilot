# Day 2 Video Script
## Hook
(30-second animation of a Python code editor)
Welcome back to Python Basics! Today, we'll cover the application of control structures and functions in Python. We'll explore how to use GUI programming to create a simple Python program.
## Learning Objectives
* Apply basic control structures (if/else statements, loops)
* Analyze and evaluate the use of functions in Python
* Create a simple Python program using a GUI library
## Content
1. Control Structures (5 minutes)
2. Functions (5 minutes)
3. GUI Programming (5 minutes)
4. Creating a Simple GUI Program (5 minutes)
## Examples
* Control structure example
* Function example
* GUI programming example
* Creating a simple GUI program example
## Summary
Recap of key concepts
## Call to Action
Start with practice exercises