# Day 2 Exercises
## Interactive Coding Exercises
1. Use an if/else statement to determine whether you're over or under 18
2. Create a function to calculate the area of a rectangle
## Group Discussion
1. When to use functions in GUI programming
2. How to create a simple GUI program using a GUI library
## Assessment
1. Quiz: control structures and functions