# Day 2 Lesson Plan
## Duration: 4 hours
## Learning Objectives
* Apply basic control structures (if/else statements, loops)
* Analyze and evaluate the use of functions in Python
* Create a simple Python program using a GUI library
## Agenda
1. Review of Control Structures (30 minutes)
2. Introduction to Functions (45 minutes)
3. GUI Programming (45 minutes)
4. Practice Exercise (30 minutes)
## Key Concepts
* Control structures (if/else statements, loops)
* Functions
* GUI programming
## Activities
* Interactive coding exercises
* Group discussion: when to use functions in GUI programming
## Assessment
* Quiz: control structures and functions