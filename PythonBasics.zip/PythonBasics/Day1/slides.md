# Day 1 Slides
## Title Slide
Python Basics
## Learning Objectives
* Recall basic Python syntax and data types
* Explain how to write and execute Python scripts
## Content Slide 1
### Basic Syntax
* Indentation
* Print statement
* Variables
## Content Slide 2
### Data Types
* Integers
* Strings
* Booleans
## Content Slide 3
### Control Structures
* If/else statements
* Loops
## Content Slide 4
### Functions
* Defining functions
* Calling functions
## Summary Slide
Recap of key concepts
## Next Steps
Start with practice exercises