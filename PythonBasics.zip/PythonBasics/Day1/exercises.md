# Day 1 Exercises
## Interactive Coding Exercises
1. Write a Python script to print your name and age
2. Use an if/else statement to determine whether you're over or under 18
## Group Discussion
1. When to use if/else statements vs. loops
2. How to use functions in Python
## Assessment
1. Quiz: basic syntax and data types