# Day 1 Lesson Plan
## Duration: 4 hours
## Learning Objectives
* Recall basic Python syntax and data types
* Explain how to write and execute Python scripts
## Agenda
1. Introduction to Python (30 minutes)
2. Basic Syntax and Data Types (45 minutes)
3. Control Structures (30 minutes)
4. Practice Exercise (30 minutes)
## Key Concepts
* Basic syntax (indentation, print, variables)
* Data types (integers, strings, booleans)
* Control structures (if/else statements, loops)
* Functions
## Activities
* Interactive coding exercises
* Group discussion: when to use if/else statements vs. loops
## Assessment
* Quiz: basic syntax and data types