# Day 1 Video Script
## Hook
(30-second animation of a Python code editor)
Hello and welcome to Python Basics! Today, we'll cover the basics of Python syntax and data types. We'll explore how to write and execute Python scripts and how to use control structures like if/else statements and loops.
## Learning Objectives
* Recall basic Python syntax and data types
* Explain how to write and execute Python scripts
## Content
1. Basic Syntax (5 minutes)
2. Data Types (5 minutes)
3. Control Structures (5 minutes)
4. Functions (5 minutes)
## Examples
* Basic syntax example
* Data type example
* Control structure example
* Function example
## Summary
Recap of key concepts
## Call to Action
Start with practice exercises